# Bagar Billi 🐱
Chat, games aur love calculator. Ek hi file: index.html
Deploy: Render, Static Site, Publish Directory = .
